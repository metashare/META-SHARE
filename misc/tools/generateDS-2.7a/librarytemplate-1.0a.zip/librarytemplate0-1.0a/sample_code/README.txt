{{schema_name}}lib sample code
-----------------------

This directory contains sample (mini-)applications that use the
{{schema_name}}lib.py module.






